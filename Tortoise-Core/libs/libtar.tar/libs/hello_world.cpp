#include <stdio.h>
#include <string>
#include <setjmp.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <list>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <string>
#include <stdio.h>
#include <cstring>
#include "xtdio.h"

int main(int argc, char **argv)
{

    std::cout << "Hello World " << argv[1] << "Starting... \n" << std::endl;
    for(int i = 0; i < argc; i++)
    {
      printf("arg #%d: %s\n",i, argv[i]);
    }
    std::cout << "Hello World " << argv[1] << "Ending..." << std::endl;    
    
    kill(atoi(argv[2]), 9);
    return 1;
}

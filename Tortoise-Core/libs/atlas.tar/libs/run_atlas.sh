#!/bin/sh

./atlas "p1=group_1_file.txt,p2=group_2_file.txt,c=group_3_file.txt" "p1->c,p2->c" #"p1"
